export type SalonSoftService = {
  id_service: string;
  name: string;
  price: string;
  duration: string;
};

export type SalonSoftProvider = {
  id_provider: string;
  name: string;
  habilitado_agendamento_online?: string;
};

export const salonData = {
  salon_name: "La barbearia ?",
  services: [
    {
      id_service: "1409780",
      name: "alfredo",
      price: "0.00",
      duration: "630",
    },
    {
      id_service: "1183698",
      name: "Barba",
      price: "30.00",
      duration: "30",
    },
    {
      id_service: "1183702",
      name: "Botox",
      price: "50.00",
      duration: "60",
    },
    {
      id_service: "1187184",
      name: "Corte",
      price: "50.00",
      duration: "40",
    },
    {
      id_service: "1369622",
      name: "Corte+Penteado",
      price: "70.00",
      duration: "60",
    },
    {
      id_service: "1369619",
      name: "Corte+Sobrancelha",
      price: "70.00",
      duration: "45",
    },
    {
      id_service: "1183699",
      name: "Corte/barba",
      price: "80.00",
      duration: "60",
    },
    {
      id_service: "1183701",
      name: "Corte/botox",
      price: "120.00",
      duration: "90",
    },
    {
      id_service: "1183700",
      name: "Corte/luzes",
      price: "150.00",
      duration: "120",
    },
    {
      id_service: "1183704",
      name: "Luzes",
      price: "70.00",
      duration: "120",
    },
    {
      id_service: "1369974",
      name: "Pezinho",
      price: "20.00",
      duration: "20",
    },
    {
      id_service: "1369595",
      name: "Relaxamento",
      price: "50.00",
      duration: "30",
    },
  ] as SalonSoftService[],
  providers: [
    {
      id_provider: "285938",
      name: "Wendel santos",
      habilitado_agendamento_online: "sim",
    },
    {
      id_provider: "327290",
      name: "Mikael Vieira",
      habilitado_agendamento_online: "sim",
    },
  ] as SalonSoftProvider[],
};
