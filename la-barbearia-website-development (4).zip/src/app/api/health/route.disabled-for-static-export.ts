// This file preserves the previous Arena-only healthcheck implementation.
// It is intentionally not named route.ts so `output: "export"` can succeed.

import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
